#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_PAGES 100
#define MAX_FRAME_SIZE 10

// Function to find the optimal page to replace
int optimalPage(int pages[], int frames[], int start, int end) {
    int result = -1, farthest = start;
    for (int i = 0; i < MAX_FRAME_SIZE; i++) {
        int j;
        for (j = start; j < end; j++) {
            if (frames[i] == pages[j]) {
                if (j > farthest) {
                    farthest = j;
                    result = i;
                }
                break;
            }
        }
        if (j == end)
            return i;
    }
    return (result == -1) ? 0 : result;
}

// Function to simulate Optimal Page Replacement
void optimalPageReplacement(int pages[], int numPages) {
    int frames[MAX_FRAME_SIZE];
    int numFrames = 0;
    int pageFaults = 0;

    for (int i = 0; i < numPages; i++) {
        bool pageFault = true;

        // Check if the page is already in a frame
        for (int j = 0; j < numFrames; j++) {
            if (frames[j] == pages[i]) {
                pageFault = false;
                break;
            }
        }

        // If page fault, replace a page using Optimal algorithm
        if (pageFault) {
            if (numFrames < MAX_FRAME_SIZE) {
                frames[numFrames++] = pages[i];
            } else {
                int replaceIndex = optimalPage(pages, frames, i + 1, numPages);
                frames[replaceIndex] = pages[i];
            }
            pageFaults++;
        }

        // Print current state of frames
        printf("Page %d: ", pages[i]);
        for (int j = 0; j < numFrames; j++) {
            printf("%d ", frames[j]);
        }
        printf("\n");
    }

    printf("Total Page Faults: %d\n", pageFaults);
}

int main() {
    int pages[MAX_PAGES];
    int numPages;

    // Input: Page reference string
    printf("Enter the number of pages: ");
    scanf("%d", &numPages);

    printf("Enter the page reference string: ");
    for (int i = 0; i < numPages; i++) {
        scanf("%d", &pages[i]);
    }

    // Simulate Optimal Page Replacement
    optimalPageReplacement(pages, numPages);

    return 0;
}
