#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_PAGES 100
#define MAX_FRAME_SIZE 10

// Function to find the index of the least recently used page
int findLRUIndex(int pages[], int frames[], int numFrames, int current) {
    int index = -1, farthest = -1;
    for (int i = 0; i < numFrames; i++) {
        int j;
        for (j = current - 1; j >= 0; j--) {
            if (frames[i] == pages[j]) {
                if (j > farthest) {
                    farthest = j;
                    index = i;
                }
                break;
            }
        }
        if (j == -1)
            return i;
    }
    return (index == -1) ? 0 : index;
}

// Function to simulate LRU Page Replacement
void lruPageReplacement(int pages[], int numPages, int numFrames) {
    int frames[MAX_FRAME_SIZE];
    int pageFaults = 0;

    for (int i = 0; i < numPages; i++) {
        bool pageFault = true;

        // Check if the page is already in a frame
        for (int j = 0; j < numFrames; j++) {
            if (frames[j] == pages[i]) {
                pageFault = false;
                break;
            }
        }

        // If page fault, replace a page using LRU algorithm
        if (pageFault) {
            if (numFrames < MAX_FRAME_SIZE) {
                frames[numFrames++] = pages[i];
            } else {
                int replaceIndex = findLRUIndex(pages, frames, numFrames, i);
                frames[replaceIndex] = pages[i];
            }
            pageFaults++;
        }

        // Print current state of frames
        printf("Page %d: ", pages[i]);
        for (int j = 0; j < numFrames; j++) {
            printf("%d ", frames[j]);
        }
        printf("\n");
    }

    printf("Total Page Faults: %d\n", pageFaults);
}

int main() {
    int pages[MAX_PAGES];
    int numPages, numFrames;

    // Input: Page reference string
    printf("Enter the number of pages: ");
    scanf("%d", &numPages);

    printf("Enter the number of frames: ");
    scanf("%d", &numFrames);

    printf("Enter the page reference string: ");
    for (int i = 0; i < numPages; i++) {
        scanf("%d", &pages[i]);
    }

    // Simulate LRU Page Replacement
    lruPageReplacement(pages, numPages, numFrames);

    return 0;
}
