#include <stdio.h>
#include <stdlib.h>

#define MAX_FRAMES 3 // Maximum number of frames in memory

// Function to find the position of a page in the frames array
int findPosition(int page, int frames[], int numFrames) {
    for (int i = 0; i < numFrames; i++) {
        if (frames[i] == page) {
            return i;
        }
    }
    return -1; // Page not found in frames
}

// Function to display the content of frames
void displayFrames(int frames[], int numFrames) {
    for (int i = 0; i < numFrames; i++) {
        if (frames[i] == -1) {
            printf("- ");
        } else {
            printf("%d ", frames[i]);
        }
    }
    printf("\n");
}

int main() {
    int referenceString[] = {1, 3, 0, 3, 5, 6, 3}; // Reference string
    int numPages = sizeof(referenceString) / sizeof(referenceString[0]);
    
    int frames[MAX_FRAMES]; // Array to represent frames in memory
    int numFrames = 0; // Number of frames currently in memory

    // Initialize frames with -1 to indicate empty frame
    for (int i = 0; i < MAX_FRAMES; i++) {
        frames[i] = -1;
    }

    int pageFaults = 0;

    // Iterate through the reference string
    for (int i = 0; i < numPages; i++) {
        int page = referenceString[i];

        // Check if the page is already in memory
        if (findPosition(page, frames, numFrames) == -1) {
            // Page fault: Page is not in memory
            if (numFrames < MAX_FRAMES) {
                // If there are empty frames, insert the page into an empty frame
                frames[numFrames++] = page;
            } else {
                // If all frames are full, replace the oldest page (FIFO)
                int oldestPageIndex = 0;
                for (int j = 1; j < MAX_FRAMES; j++) {
                    if (frames[j] < frames[oldestPageIndex]) {
                        oldestPageIndex = j;
                    }
                }
                frames[oldestPageIndex] = page;
            }

            pageFaults++;

            // Display the current state of frames after the page replacement
            displayFrames(frames, MAX_FRAMES);
        }
    }

    printf("Total Page Faults: %d\n", pageFaults);

    return 0;
}
